﻿using System.ComponentModel.DataAnnotations;

namespace HousingWebApp.Models
{
    public class AppUser
    {
        [Required]
        public string FirstName { get; set; }
        [MaxLength(20)]
        public string LastName { get; set; }

        [Required]
        [EmailAddress]
        //[MinLength(5)]
        public string Email { get; set; }
        [Required]
        [EmailAddress]
        [Compare("Email")]
        //[Range(5, 20)]
        public string ConfirmEmail { get; set; }

        [Required]

        [DataType(DataType.Password)]
        public string Password { get; set; }
        [Required]
        [DataType(DataType.Password)]
        [Compare("Password")]
        public string ConfirmPassword { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
    }
}
