﻿using Microsoft.EntityFrameworkCore;

namespace HousingWebApp.Models
{
    public class AramDB : DbContext
    {
        public AramDB(DbContextOptions<DbContext> options) : base(options)
        {
        }
        public DbSet<AppUser> AppUsers { get; set; }
    }
}
